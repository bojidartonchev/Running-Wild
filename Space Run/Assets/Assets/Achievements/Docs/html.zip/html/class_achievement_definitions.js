var class_achievement_definitions =
[
    [ "categories", "class_achievement_definitions.html#a4618219f65918fbbc6505db49271684e", null ],
    [ "definitions", "class_achievement_definitions.html#a7b3352366b5ff8a1253ca0eca46407f3", null ],
    [ "maxCatId", "class_achievement_definitions.html#a257f54857ecff7bee6cc8e1811bf2a5d", null ]
];
var searchData=
[
  ['definitions',['definitions',['../class_achievement_definitions.html#a7b3352366b5ff8a1253ca0eca46407f3',1,'AchievementDefinitions']]],
  ['description',['description',['../class_achievement_definition.html#a6527609f8e92653f54d8eef0c4975c98',1,'AchievementDefinition']]]
];

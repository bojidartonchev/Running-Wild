var searchData=
[
  ['title',['title',['../class_achievement_definition.html#ae4b52b4ecdc467af7081dd2622b01aa0',1,'AchievementDefinition']]],
  ['type',['type',['../class_achievement_definition.html#a9f9a1a4a1ee0e0d6ef058925347a2cd9',1,'AchievementDefinition']]]
];

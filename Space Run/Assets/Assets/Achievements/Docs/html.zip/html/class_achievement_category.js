var class_achievement_category =
[
    [ "id", "class_achievement_category.html#abfa3d8a59f8414314e46ff75af8c8013", null ],
    [ "name", "class_achievement_category.html#a26ab77b339aa87cd3466ffd417ea99f6", null ]
];
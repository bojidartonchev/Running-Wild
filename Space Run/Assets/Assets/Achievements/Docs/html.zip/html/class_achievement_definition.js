var class_achievement_definition =
[
    [ "Type", "class_achievement_definition.html#abf5f3b4eb26d9456052a20ed5ecc2baf", null ],
    [ "categoryId", "class_achievement_definition.html#af189b10024f80ffa6ec1052ea35cea43", null ],
    [ "conditionBoolValue", "class_achievement_definition.html#a386fc07d8b9573f69544928583e99584", null ],
    [ "conditionFloatValue", "class_achievement_definition.html#a2da080126ed87366c2675c63a2b852da", null ],
    [ "conditionIntValue", "class_achievement_definition.html#a06ff25bbbb6b365006bced5f6086fe1f", null ],
    [ "description", "class_achievement_definition.html#a6527609f8e92653f54d8eef0c4975c98", null ],
    [ "hidden", "class_achievement_definition.html#a4431980b957b57ccb74bf5aea82031eb", null ],
    [ "incompleteDescription", "class_achievement_definition.html#a7605eae1ea327680d258bf3537487b14", null ],
    [ "name", "class_achievement_definition.html#a84b5f887ae0560a6d87f214b63a1df37", null ],
    [ "progressChangeSize", "class_achievement_definition.html#a4cc7b102c6088fb46636f350203508ea", null ],
    [ "title", "class_achievement_definition.html#ae4b52b4ecdc467af7081dd2622b01aa0", null ],
    [ "type", "class_achievement_definition.html#a9f9a1a4a1ee0e0d6ef058925347a2cd9", null ]
];
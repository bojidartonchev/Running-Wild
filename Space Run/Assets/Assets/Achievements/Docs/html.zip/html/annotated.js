var annotated =
[
    [ "AchievementCategory", "class_achievement_category.html", "class_achievement_category" ],
    [ "AchievementDefinition", "class_achievement_definition.html", "class_achievement_definition" ],
    [ "AchievementDefinitions", "class_achievement_definitions.html", "class_achievement_definitions" ],
    [ "Achievement.AchievementManager", "class_achievement_1_1_achievement_manager.html", "class_achievement_1_1_achievement_manager" ],
    [ "Achievement.AchievementManager.AchievementState", "class_achievement_1_1_achievement_manager_1_1_achievement_state.html", "class_achievement_1_1_achievement_manager_1_1_achievement_state" ],
    [ "Achievement.AchievementVariable< T >", "class_achievement_1_1_achievement_variable-g.html", "class_achievement_1_1_achievement_variable-g" ]
];